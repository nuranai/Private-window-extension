Private window save extension

For TSU work